package com.example.affirmations.model

data class Affirmation(val stringResourceId: Int)